module.exports={
    jwtsecret:"ram"
}
